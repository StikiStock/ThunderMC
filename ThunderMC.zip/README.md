
# ThunderMc.iR (Incomplete)

*This repository is an ongoing project*

The future template of ThunderMc.IR - I decided to make the source open to public for education purposes.
Feel free to open a pull request for any reason

## Features

- Fully Responsive
- Written in Tailwind
- Dark theme
- Light Mode Toggle (Soon)
- Scroll animations
- According to global Standard UX
- Made with love

## Optimizations

// There will be a long list of Used Optimization Methods in this section soon enough.
I will implement the optimizations right after the website design is fully complete.
## Authors

- [@StikiStock](https://www.stiki.ir)

